'use client';

import { motion } from 'framer-motion';
import { FadeIn } from '@/components/ui/fade-in';
import { SectionHeading } from '@/components/ui/section-heading';
import { serviceItems } from '@/lib/site-data';

const gridVariants = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

export function ServicesSection() {
  return (
    <section id="servicos" className="border-b border-brand-line py-12 sm:py-16">
      <div className="container-shell">
        <SectionHeading
          eyebrow="Serviços"
          title={
            <>
              Soluções completas em construção, remodelação e reabilitação, com acompanhamento sério do início ao fim.
            </>
          }
          description={
            <>
              Trabalhamos com diferentes tipos de intervenção, sempre com foco na boa execução, na clareza do processo e na qualidade final de cada espaço.
            </>
          }
        />

        <motion.div
          variants={gridVariants}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.1 }}
          className="mt-14 grid gap-5 md:grid-cols-2 xl:grid-cols-4"
        >
          {serviceItems.map((item) => {
            const Icon = item.icon;

            return (
              <FadeIn
                key={item.title}
                className="rounded-[1.8rem] border border-brand-line bg-white p-6 shadow-[0_16px_40px_rgba(0,0,0,0.04)]"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-soft text-brand-accent">
                  <Icon className="h-5 w-5" />
                </div>

                <h3 className="mt-6 font-serif text-3xl leading-none">
                  {item.title}
                </h3>

                <p className="mt-4 text-base leading-8 text-brand-muted">
                  {item.description}
                </p>
              </FadeIn>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}